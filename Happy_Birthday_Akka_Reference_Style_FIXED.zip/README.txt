HAPPY BIRTHDAY AKKA — REFERENCE STYLE WEBSITE

Fixed version:
- Removed the previous plain four-box section.
- Replaced it with a reference-style 2-column photo + message section.
- Uses all six supplied photos.
- Uses the supplied brother/sister love song.
- Birthday: 17 October 2026.
- Countdown runs to the birthday.
- Song is configured to autoplay on opening. Modern browsers may block audible
  autoplay; in that case the first click/touch anywhere starts it automatically.

Open index.html in Chrome/Firefox.
